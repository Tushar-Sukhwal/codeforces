class QueueWithTwoStacks:
    def __init__(self):
        self.stack1 = []  # enqueue
        self.stack2 = []  # dequeue

    def enqueue(self, x):
        # Push the element onto stack1
        self.stack1.append(x)

    def dequeue(self):
        # If stack2 is empty, transfer all elements from stack1 to stack2
        if not self.stack2:
            while self.stack1:
                self.stack2.append(self.stack1.pop())
        # Pop the top element from stack2
        if self.stack2:
            return self.stack2.pop()
        else:
            print("Dequeue from an empty queue")

    def peek(self):
        # If stack2 is empty, transfer all elements from stack1 to stack2
        if not self.stack2:
            while self.stack1:
                self.stack2.append(self.stack1.pop())
        # Return the top element from stack2
        if self.stack2:
            return self.stack2[-1]
        else:
            print("Peek from an empty queue")

    def is_empty(self):
        # The queue is empty if both stacks are empty
        return not self.stack1 and not self.stack2

# Example usage:
queue = QueueWithTwoStacks()
queue.enqueue(1)
queue.enqueue(2)
queue.enqueue(3)

print(queue.dequeue())  #  1
print(queue.peek())     #  2
print(queue.dequeue())  #  2
print(queue.is_empty()) # False
print(queue.dequeue())  #  3
print(queue.is_empty()) #  True