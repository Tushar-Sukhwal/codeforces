'''We can use quickselect inspired from quicksort to find the median
    so we will take the pivot and partition the array and check, 
    - if we got the 500,000 th element then we will return it as median 
    - if we got the element less than 500,000 then we will search in the right partition
    - if we got the element greater than 500,000 then we will search in the left partition
    - we will keep on doing this until we get the 500,000 th element
    - the time complexity of this approach is O(n) in the average case
'''

import numpy as np

def quickselect(arr, k):

    if len(arr) == 1:
        return arr[0]
    
    # Choose a pivot (e.g., the first element)
    pivot = arr[0]
    
    # Partition 
    left = [x for x in arr if x < pivot]
    right = [x for x in arr if x > pivot]
    equal = [x for x in arr if x == pivot]
    

    if k < len(left):
        return quickselect(left, k)
    elif k < len(left) + len(equal):
        return equal[0]
    else:
        return quickselect(right, k - len(left) - len(equal))

def find_median(arr):

    n = len(arr)
    mid = n // 2  # Middle index for 1,000,001 elements
    return quickselect(arr, mid)

# Generate an array with 1,000,001 random numbers
arr = np.random.random(1_000_001)

# Find the median
median = find_median(arr)
print("Median:", median)