"""
Merges two sorted subarrays into a single sorted subarray.

Precondition:
- data has at least n1 + n2 elements starting at data[first].
- The first n1 elements (from data[first] to data[first + n1 - 1]) are sorted.
- The last n2 elements (from data[first + n1] to data[first + n1 + n2 - 1]) are sorted.

Postcondition:
- The elements from data[first] to data[first + n1 + n2 - 1] are sorted in ascending order.
"""


#this is a function used in merge sort algorithm 
def merge(data, first, n1, n2):
    # temprary array 
    temp = [0] * (n1 + n2)


    i = first  
    j = first + n1  
    k = 0  


    while i < first + n1 and j < first + n1 + n2:
        if data[i] <= data[j]:
            temp[k] = data[i]
            i += 1
        else:
            temp[k] = data[j]
            j += 1
        k += 1


    while i < first + n1:
        temp[k] = data[i]
        i += 1
        k += 1


    while j < first + n1 + n2:
        temp[k] = data[j]
        j += 1
        k += 1

    for idx in range(n1 + n2):
        data[first + idx] = temp[idx]


# Example 
data = [1, 3, 5, 7, 2, 4, 6, 8]
first = 0
n1 = 4  # [1, 3, 5, 7]
n2 = 4  # S[2, 4, 6, 8]

merge(data, first, n1, n2)
print("Merged array:", data)  #  [1, 2, 3, 4, 5, 6, 7, 8]
